const userPassword = 'puntos'; // La contraseña para los usuarios
const devPassword = 'topsecret'; // La contraseña para los desarrolladores
const authForm = document.getElementById('authForm');
const passwordInput = document.getElementById('password');
const authSection = document.getElementById('authSection');
const emailSection = document.getElementById('emailSection');
const emailForm = document.getElementById('emailForm');
const emailInput = document.getElementById('email');
const mainSection = document.getElementById('mainSection');
const usersList = document.getElementById('usersList');
const registerButton = document.getElementById('registerButton');
const registerSection = document.getElementById('registerSection');
const registerForm = document.getElementById('registerForm');
const registerNameInput = document.getElementById('registerName');
const registerEmailInput = document.getElementById('registerEmail');
const backToLoginButton = document.getElementById('backToLoginButton');

let users = JSON.parse(localStorage.getItem('users')) || [];
let isAdmin = false;
let loggedInUser = null;

// Manejo del botón de registro
registerButton.addEventListener('click', () => {
    authSection.style.display = 'none';
    registerSection.style.display = 'block';
});

// Manejo del botón de volver
backToLoginButton.addEventListener('click', () => {
    registerSection.style.display = 'none';
    authSection.style.display = 'block';
});

// Manejo del formulario de registro
registerForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const userName = registerNameInput.value.trim();
    const userEmail = registerEmailInput.value.trim();

    if (userName && userEmail && !isUserExist(userEmail)) {
        const user = {
            name: userName,
            email: userEmail,
            points: 100000
        };
        users.push(user);
        saveUsers();
        alert('Registro exitoso. Ahora puedes iniciar sesión.');
        registerNameInput.value = '';
        registerEmailInput.value = '';
        registerSection.style.display = 'none';
        authSection.style.display = 'block';
    } else {
        alert('El usuario ya existe o los campos están vacíos.');
    }
});

// Manejo del formulario de autenticación
authForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const password = passwordInput.value;
    if (password === userPassword || password === devPassword) {
        isAdmin = (password === devPassword);
        authSection.style.display = 'none';
        if (isAdmin) {
            mainSection.style.display = 'block';
            renderUsers();
        } else {
            emailSection.style.display = 'block';
        }
    } else {
        alert('Contraseña incorrecta.');
        passwordInput.value = '';
    }
});

// Manejo del formulario de introducción de correo electrónico para usuarios
emailForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = emailInput.value.trim();
    if (isUserExist(email)) {
        loggedInUser = getUserByEmail(email);
        emailSection.style.display = 'none';
        mainSection.style.display = 'block';
        renderUser(loggedInUser);
    } else {
        alert('Correo electrónico no encontrado.');
    }
});

function isUserExist(email) {
    return users.some(user => user.email === email);
}

function getUserByEmail(email) {
    return users.find(user => user.email === email);
}

function renderUser(user) {
    usersList.innerHTML = '';
    const userCard = document.createElement('div');
    userCard.className = 'user-card';

    const userInfo = document.createElement('div');
    userInfo.className = 'user-info';
    userInfo.innerHTML = `
        <p><strong>Nombre:</strong> ${user.name}</p>
        <p><strong>Email:</strong> ${user.email}</p>
        <p class="points"><strong>Puntos:</strong> ${user.points}</p>
    `;

    userCard.appendChild(userInfo);
    usersList.appendChild(userCard);
}

function renderUsers() {
    usersList.innerHTML = '';
    users.forEach((user, index) => {
        const userCard = document.createElement('div');
        userCard.className = 'user-card';

        const userInfo = document.createElement('div');
        userInfo.className = 'user-info';
        userInfo.innerHTML = `
            <p><strong>Nombre:</strong> ${user.name}</p>
            <p><strong>Email:</strong> ${user.email}</p>
            <p class="points"><strong>Puntos:</strong> ${user.points}</p>
        `;

        userCard.appendChild(userInfo);

        if (isAdmin) {
            const userActions = document.createElement('div');
            userActions.className = 'user-actions';

            const addPointsButton = document.createElement('button');
            addPointsButton.className = 'btn';
            addPointsButton.textContent = '+1000';
            addPointsButton.addEventListener('click', () => changePoints(index, 1000));

            const removePointsButton = document.createElement('button');
            removePointsButton.className = 'btn';
            removePointsButton.textContent = '-1000';
            removePointsButton.addEventListener('click', () => changePoints(index, -1000));

            userActions.appendChild(addPointsButton);
            userActions.appendChild(removePointsButton);
            userCard.appendChild(userActions);
        }

        usersList.appendChild(userCard);
    });
}

function changePoints(index, amount) {
    users[index].points += amount;
    saveUsers();
    renderUsers();
}

function saveUsers() {
    localStorage.setItem('users', JSON.stringify(users));
}

